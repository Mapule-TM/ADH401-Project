package com.tweet.DataTransferObj;

import java.io.Serializable;
//import java.util.Date;
import java.util.Date;

public class tweetDTO implements Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1258132044488963724L;
	private Date twitterTimeStamp;
	private Integer twitterID;
	private String twitterBody;
	
	
	public Date getTwitterTimeStamp()
	{
		return twitterTimeStamp;
	}
	
	public void setTwitterTimeStamp(Date twitterTimeStamp)
	{
		this.twitterTimeStamp = twitterTimeStamp;
	}
	
	public Integer getTwitterID() 
	{
		return twitterID;
	}

	public void setTwitterID(Integer twitterID)
	{
		this.twitterID = twitterID;
	}
	
	public String getTwitterBody()
	{
		return twitterBody;
	}
	
	public void setTwitterBody(String twitterBody)
	{
		this.twitterBody = twitterBody;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
}
