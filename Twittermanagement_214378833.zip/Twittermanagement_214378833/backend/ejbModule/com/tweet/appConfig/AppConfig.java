package com.tweet.appConfig;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

//startup root of our rest
@ApplicationPath("rest")
public class AppConfig extends Application{
	

}
