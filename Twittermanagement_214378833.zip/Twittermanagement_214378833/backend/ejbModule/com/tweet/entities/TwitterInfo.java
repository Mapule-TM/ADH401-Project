package com.tweet.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;

//import javax.persistence.NamedQueries;
import javax.persistence.TemporalType;

@Entity
@Table(name="Twitter_Information")
@NamedQueries(
		{@NamedQueries(name="TwitterInfo.findAll", query="SELECT t FROM TwitterInfo t")
		})

public class TwitterInfo implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="twitter_id")
	private Integer twitterID;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="tweet_timestamp")
	private Date twitterTimeStamp;
	
	@Column(name="twitter_body")
	private String twitterbody;
	
	
	//......
	public TwitterDetail()
	{
		
	}
	
	public Integer getTwitterID()
	{
		return twitterID;
	}
	
	public void setTwitterID(Integer twitterID)
	{
		this.twitterID = twitterID;
	}
	
	
	public Date getTwitterTimeStamp() {
		return twitterTimeStamp;
	}

	public void setTwitterTimeStamp(Date twitterTimeStamp) 
	{
		this.twitterTimeStamp = twitterTimeStamp;
	}

	public String getTwitterBody() 
	{
		return twitterBody;
	}

	public void setTwitterBody(String twitterBody) 
	{
		this.twitterBody = twitterBody;
	}
	
	
	
	
	
	
	
	
	
	
	
	
}

