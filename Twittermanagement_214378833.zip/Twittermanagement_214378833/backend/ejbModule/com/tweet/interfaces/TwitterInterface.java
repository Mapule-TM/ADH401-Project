package com.tweet.interfaces;

import java.util.List;
import com.tweet.DataTransferObj.tweetDTO;
import com.tweet.entities.TwitterInfo;

import twitter4j.DirectMessage;
import twitter4j.Status;
import twitter4j.TwitterException;

public class TwitterInterface {
	List<tweetDTO> getAllTweetsByID();
	TwitterInfo saveTweet(tweetDTO tweetDTO);
	void postTweet(String message) throw TwitterException;
	DirectMessage  sendDirectTweetMessage(String recipientName, String message) throw TwitterException;
	List<Status> getAllPost() throws TwitterException;

}
