package com.tweet.resource;

import java.awt.PageAttributes.MediaType;
import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;
import javax.websocket.server.PathParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.tweet.DataTransferObj.tweetDTO;
import com.tweet.entities.TwitterInfo;
import com.tweet.services.TwitterService;

@Path("/tweets")
public class TweetResource {
	
	@Inject 
	TwitterService twitterService;
	
	@POST
	@Path("/CreateTweet")
	@Consumes(MediaType.APPLICATION_JASON)
	@Produces(MediaType.APPLCATION_JASON)
	
	//edit
	public Response createTweet(tweetDTO tweetDTO)
	{
		TwitterInfo dto = tweetService.saveTweet(tweetDTO);
		return Response.ok(dto).build();
	}

	@GET
	@Path("/findAllTweets")
	@Produces(MediaType.APPLICATION_JASON)
	
	public List<tweetDTO> findAlltweets()
	{
		return twitterService.getAllTweetsByID();
	}
	
}

