package com.tweet.services;


import java.util.Date;
import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import com.tweet.interfaces.TwitterInterface;
import com.tweet.DataTransferObj.tweetDTO;
import com.tweet.entities.TwitterInfo;

import twitter4j.DirectMessage;
import twitter4j.Status;
import twitter4j.StatusUpdate;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.auth.AccessToken;

@Stateless
@localBean
public class TwitterService implements TwitterInterface{
	
	@PersistenceContext
	EntityManager em;
	
	private static final String consumerKey = "5hFtf3L2Tvd5KSKEcemjHvW0v";

	private static final String consumerSecret = "uuZcyvHmWodfOfW4Zvm697gHcP63ChRo1Vq0jG6BJ3BAb6VAKX ";

	private static final String accessToken = "1341534704-LEHWFDHkRh0E4VKrX1nEYoUVQuoR0vORBUI2aMX";

	private static final String accessTokenSecret = "AnE2gmTWqNCesjt1CRa71MmJ2zrL6vu6RRHZdEcAtDvdc";
	
	TwitterFactory twitterFactory = new TwitterFactory();

	Twitter twitter = twitterFactory.getInstance();
	
	@SuppressWarnings("unchecked")
	@Override
	public List<tweetDTO> getAllTweetsByID() {
		Query query = em.createNamedQuery("TwitterInfo.findAll");
		return (List<tweetDTO>) query.getResultList();
	}

	@Override
	public TwitterInfo saveTweet(tweetDTO tweetDTO) {
		TwitterInfo twitterInfo = new TwitterInfo();
		if (tweetDTO != null) {
			twitterInfo.setTwitterBody(tweetDTO.getTwitterBody());
			twitterInfo.setTwitterTimeStamp(new Date());
			em.persist(twitterInfo);
			try {
				postTweet(twitterInfo.getTwitterBody());
			} catch (TwitterException e) {
				e.printStackTrace();
			}
		}
		return twitterInfo;
	}
	
	@Override
	public void postTweet(String twitterBody) throws TwitterException {
		
		String recipientName = "@AdhLecturer";
		
		twitter.setOAuthConsumer(consumerKey, consumerSecret);

		twitter.setOAuthAccessToken(new AccessToken(accessToken, accessTokenSecret));

		StatusUpdate statusUpdate = new StatusUpdate(twitterBody);

		twitter.updateStatus(statusUpdate);
		sendDirectTweetMessage(recipientName,twitterBody);
		List<Status> timeLineStatus = getAllPost();
		
		if(!timeLineStatus.isEmpty()) {
			for(Status status : timeLineStatus) {
				System.out.println("All time lines getText " + status.getText() + " status.getPlace " + status.getPlace());
			}
		}
	}

	@Override
	public DirectMessage sendDirectTweetMessage(String recipientName, String message) throws TwitterException {
		return twitter.sendDirectMessage(recipientName, message);
	}

	@Override
	public List<Status> getAllPost() throws TwitterException {
		return twitter.getHomeTimeline();
	}
	
}

















