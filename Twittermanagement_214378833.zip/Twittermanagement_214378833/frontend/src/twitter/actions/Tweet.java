package twitter.actions;

public class Tweet {

	//path name for tweet_resource
	public static final String URL = "http://localhost:8080/twitterApp/rest/tweets/";
	public static final String CREATE_NEW_TWEET = "CreateTweet";
	public static final String GET_ALL_TWEETS = "findAllTweet";
}
