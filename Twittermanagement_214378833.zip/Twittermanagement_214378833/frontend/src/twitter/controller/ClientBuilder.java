package twitter.controller;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;

public class ClientBuilder {

}
