package twitter.controller;

import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.GenericType;

import twitter.model.TwitterDTO;
import twitter.actions.Tweet;


@ManagedBean(name = "twitterController")
@SessionScoped
public class TwitterController 
{

	Client client = ClientBuilder.newClient();
	private List<TwitterDTO> tweetsList;
	private String twitterBody;
	private List<TwitterDTO> twitterList;

	public void getAllTweets() 
	{
		this.tweetsList = client.target(Tweet.URL + Tweet.GET_ALL_TWEETS).request()
				.get(new GenericType<List<TwitterDTO>>() );
	}

	public void saveTweet() {
		String status = client.target(Tweet.URL+Tweet.CREATE_NEW_TWEET).request().post(Entity.json(twitterBody()),String.class);
		if(status != null) {
		
		}
	}

	public void clearTweets() {
		if (this.tweetsList != null) {
			tweetsList.clear();
		}
	}

	private TwitterDTO twitterBody() {
		TwitterDTO dto = new TwitterDTO();
		dto.setTwitterBody(twitterBody);
		return dto;
	}

	public String getTwitterBody() {
		return twitterBody;
	}

	public void setTwitterBody(String twitterBody) {
		this.twitterBody = twitterBody;
	}

	public List<TwitterDTO> getTwitterList() {
		return twitterList;
	}

	public void setTwitterList(List<TwitterDTO> twitterList) {
		this.twitterList = twitterList;
	}

}
