package twitter.model;

import java.io.Serializable;
//import java.io.Serializable;
import java.util.Date;

public class TwitterDTO implements Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7451522563541206311L;
	private Date twitterTimeStamp;
	private Integer twitterID;
	private String twitterBody;


	public Date getTwitterTimeStamp() {
		return twitterTimeStamp;
	}

	public void setTwitterTimeStamp(Date twitterTimeStamp) {
		this.twitterTimeStamp = twitterTimeStamp;
	}

	public Integer getTwitterID() {
		return twitterID;
	}

	public void setTwitterID(Integer twitterID) {
		this.twitterID = twitterID;
	}
	
	public String getTwitterBody() {
		return twitterBody;
	}

	public void setTwitterBody(String twitterBody) {
		// TODO Auto-generated method stub
		this.twitterBody = twitterBody;
	}
	@Override
	public String toString() {
		return "TwitterDTO [twitterID=" + twitterID + ", twitterTimeStamp=" + twitterTimeStamp + ", twitterBody=" + twitterBody + "]";

	}


}
